<?php exit(0); ?>
{"master": "ECQtUTPHNf1m2iFOdA4uylcn82jGcYQb77Eq6jQnwRw=", "admin_user": "easyssh-admin", "admin_hash": "$2y$10$kl/23oQeG6fITSUOm4LW0.oQOHKTg2pcKbXaGUDudeJ9f.dvjuKvO", "token_secret": "c1c3433a3786fd27fb276e075d620b70e276f7bded390351ac25710eab0933b4"}
