<?php
/**
 * POST /api/feedback/admin.php —— 反馈后台管理接口（管理员令牌鉴权）
 * 动作（JSON body）：
 *   { action:"login",    user, pass }                       → { ok, token }
 *   { action:"list",     user, token }                      → { ok, items:[...] }
 *   { action:"add",      user, token, type, contact, content, public }
 *   { action:"edit",     user, token, id, type?, contact?, content? }
 *   { action:"delete",   user, token, id }
 *   { action:"reply",    user, token, id, reply }           → 同时标记为已回复
 *   { action:"setpublic",user, token, id, public }          → 是否公开到前端 TOP10
 */
require __DIR__ . '/common.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') fb_fail('仅支持 POST', 405);
$in = json_decode(file_get_contents('php://input'), true);
if (!is_array($in)) fb_fail('请求体必须是 JSON');
$action = (string)($in['action'] ?? '');
$user = (string)($in['user'] ?? '');
$token = (string)($in['token'] ?? '');
$keys = fb_keys();

if ($action === 'login') {
  $pass = (string)($in['pass'] ?? '');
  if ($user !== ($keys['admin_user'] ?? '') || !password_verify($pass, (string)($keys['admin_hash'] ?? ''))) {
    usleep(400 * 1000); // 减缓爆破
    fb_fail('用户名或密码错误', 401);
  }
  fb_json_out(['ok' => true, 'token' => fb_token_for($user), 'user' => $user]);
}

if (!fb_check_token($user, $token)) fb_fail('未登录或登录已过期，请重新登录', 401);

$db = fb_db_load();
$find = function ($id) use (&$db) {
  foreach ($db['items'] as $i => $it) if (($it['id'] ?? '') === $id) return $i;
  return -1;
};
$now = fb_now_ms();

switch ($action) {
  case 'list':
    // 按提交时间倒序
    usort($db['items'], function ($a, $b) { return (int)($b['ts'] ?? 0) <=> (int)($a['ts'] ?? 0); });
    fb_json_out(['ok' => true, 'items' => $db['items'], 'total' => count($db['items'])]);

  case 'add':
    $type = trim((string)($in['type'] ?? '其他'));
    if (!in_array($type, FB_TYPES, true)) $type = '其他';
    $content = trim((string)($in['content'] ?? ''));
    if (mb_strlen($content) < 5 || mb_strlen($content) > FB_MAX_CONTENT) fb_fail('内容需为 5-' . FB_MAX_CONTENT . ' 个字符');
    $contact = mb_substr(trim((string)($in['contact'] ?? '')), 0, FB_MAX_CONTACT);
    $id = 'fb' . base_convert((string)$now, 10, 36) . bin2hex(random_bytes(2));
    $db['items'][] = [
      'id' => $id, 'ts' => $now, 'date' => fb_date_str($now), 'ipHash' => '',
      'appVersion' => '', 'type' => $type, 'contact' => $contact, 'content' => $content,
      'reply' => '', 'replyAt' => 0, 'public' => (bool)($in['public'] ?? false), 'status' => 'new',
    ];
    fb_db_save($db);
    fb_json_out(['ok' => true, 'id' => $id]);

  case 'edit':
    $i = $find((string)($in['id'] ?? ''));
    if ($i < 0) fb_fail('反馈不存在', 404);
    foreach (['type' => FB_TYPES, 'contact' => null, 'content' => null] as $f => $allowed) {
      if (array_key_exists($f, $in)) {
        $v = trim((string)$in[$f]);
        if (is_array($allowed) && !in_array($v, $allowed, true)) fb_fail('类型非法');
        if ($f === 'content' && (mb_strlen($v) < 5 || mb_strlen($v) > FB_MAX_CONTENT)) fb_fail('内容需为 5-' . FB_MAX_CONTENT . ' 个字符');
        if ($f === 'contact') $v = mb_substr($v, 0, FB_MAX_CONTACT);
        $db['items'][$i][$f] = $v;
      }
    }
    fb_db_save($db);
    fb_json_out(['ok' => true]);

  case 'delete':
    $i = $find((string)($in['id'] ?? ''));
    if ($i < 0) fb_fail('反馈不存在', 404);
    array_splice($db['items'], $i, 1);
    fb_db_save($db);
    fb_json_out(['ok' => true]);

  case 'reply':
    $i = $find((string)($in['id'] ?? ''));
    if ($i < 0) fb_fail('反馈不存在', 404);
    $reply = trim((string)($in['reply'] ?? ''));
    if ($reply === '' || mb_strlen($reply) > FB_MAX_CONTENT) fb_fail('回复内容需为 1-' . FB_MAX_CONTENT . ' 个字符');
    $db['items'][$i]['reply'] = $reply;
    $db['items'][$i]['replyAt'] = $now;
    $db['items'][$i]['status'] = 'replied';
    fb_db_save($db);
    fb_json_out(['ok' => true]);

  case 'setpublic':
    $i = $find((string)($in['id'] ?? ''));
    if ($i < 0) fb_fail('反馈不存在', 404);
    $db['items'][$i]['public'] = (bool)($in['public'] ?? false);
    fb_db_save($db);
    fb_json_out(['ok' => true]);

  default:
    fb_fail('未知动作');
}
