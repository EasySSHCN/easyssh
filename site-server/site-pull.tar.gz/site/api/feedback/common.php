<?php
/**
 * EasySSH 使用反馈 — 公共函数（网站端）
 *
 * 密钥与凭据存放于同目录 keys.php（PHP 退出守卫：首行 <?php exit(0); ?>，
 * 直接 HTTP 访问只会得到空响应，不会泄漏内容）。该文件属于敏感配置（SANITIZED 策略同
 * update-keys.json），不得随源码 zip / 版本库对外发布。
 *
 * 反馈协议（与在线升级检测接口同族，客户端 updater.js / main.js 同一套派生方式）：
 *   信封 = { "v":1, "alg":"A256GCM-HS256", "ts":<ms>, "nonce":b64, "ct":b64, "tag":b64, "mac":b64 }
 *   明文 = 反馈内容 JSON（UTF-8）
 *   ct   = AES-256-GCM(fbEncKey, nonce, 明文)
 *   mac  = HMAC-SHA256(fbMacKey, `${ts}.${nonce}.${ct}.${tag}`)  (b64)
 *   fbEncKey / fbMacKey = HKDF-SHA256(master, salt='easyssh-feedback-v1', info) 派生
 * 服务端校验：mac → ts 时效(±15 分钟) → 解密。
 */

define('FB_SALT', 'easyssh-feedback-v1');
define('FB_DB', __DIR__ . '/../../data/feedback-db.json');
define('FB_KEYS', __DIR__ . '/keys.php');
define('FB_TYPES', ['功能建议', '问题反馈', '其他']);
define('FB_MAX_CONTENT', 2000);
define('FB_MAX_CONTACT', 120);
define('FB_TS_WINDOW_MS', 15 * 60 * 1000);
define('FB_RATE_PER_HOUR', 5);
define('FB_RATE_MIN_GAP_MS', 60 * 1000);

function fb_json_out($obj, $code = 200) {
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  header('Cache-Control: no-store');
  echo json_encode($obj, JSON_UNESCAPED_UNICODE);
  exit;
}

function fb_fail($msg, $code = 400) { fb_json_out(['ok' => false, 'message' => $msg], $code); }

/** 读取 keys.php 中 PHP 退出守卫之后的 JSON 配置 */
function fb_keys() {
  static $keys = null;
  if ($keys !== null) return $keys;
  if (!is_readable(FB_KEYS)) fb_fail('服务端配置缺失', 500);
  $lines = file(FB_KEYS, FILE_IGNORE_NEW_LINES);
  if (!$lines || count($lines) < 2) fb_fail('服务端配置损坏', 500);
  $json = implode("\n", array_slice($lines, 1));
  $keys = json_decode($json, true);
  if (!is_array($keys) || empty($keys['master'])) fb_fail('服务端配置损坏', 500);
  return $keys;
}

function fb_b64d($s) {
  $d = base64_decode((string)$s, true);
  if ($d === false) fb_fail('信封编码非法');
  return $d;
}

/** 派生反馈加解密密钥对（HMAC-SHA256 派生，跨 PHP/Node 行为完全一致，不依赖 HKDF） */
function fb_derive($masterRaw) {
  return [
    'enc' => hash_hmac('sha256', 'enc', $masterRaw, true),
    'mac' => hash_hmac('sha256', 'mac', $masterRaw, true),
  ];
}

/** 校验并解密请求信封，返回明文关联数组 */
function fb_decrypt_envelope($env) {
  if (!is_array($env) || ($env['alg'] ?? '') !== 'A256GCM-HS256' || ($env['v'] ?? 0) != 1) {
    fb_fail('信封格式非法');
  }
  $keys = fb_keys();
  $k = fb_derive(base64_decode($keys['master'], true));
  $ts = (string)($env['ts'] ?? '');
  $nonce = fb_b64d($env['nonce'] ?? '');
  $ct = fb_b64d($env['ct'] ?? '');
  $tag = fb_b64d($env['tag'] ?? '');
  $mac = fb_b64d($env['mac'] ?? '');
  if (strlen($nonce) !== 12 || strlen($tag) !== 16) fb_fail('信封参数非法');
  if (abs((int)$ts - (int)(microtime(true) * 1000)) > FB_TS_WINDOW_MS) fb_fail('请求已过期，请校对本机时间后重试');
  $want = hash_hmac('sha256', $ts . '.' . ($env['nonce'] ?? '') . '.' . ($env['ct'] ?? '') . '.' . ($env['tag'] ?? ''), $k['mac'], true);
  if (!hash_equals($want, $mac)) fb_fail('信封签名校验失败');
  $plain = openssl_decrypt($ct, 'aes-256-gcm', $k['enc'], OPENSSL_RAW_DATA, $nonce, $tag);
  if ($plain === false) fb_fail('解密失败');
  $data = json_decode($plain, true);
  if (!is_array($data)) fb_fail('解密后内容非法');
  return $data;
}

/** 读取反馈库（不存在时返回空结构） */
function fb_db_load() {
  if (!is_readable(FB_DB)) return ['items' => []];
  $j = json_decode((string)file_get_contents(FB_DB), true);
  if (!is_array($j) || !isset($j['items']) || !is_array($j['items'])) return ['items' => []];
  return $j;
}

/** 原子写回反馈库 */
function fb_db_save($db) {
  $dir = dirname(FB_DB);
  if (!is_dir($dir)) @mkdir($dir, 02775, true);
  $tmp = FB_DB . '.tmp.' . getmypid();
  if (@file_put_contents($tmp, json_encode($db, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX) === false) {
    fb_fail('服务器存储写入失败', 500);
  }
  @chmod($tmp, 0664);
  if (!@rename($tmp, FB_DB)) { @unlink($tmp); fb_fail('服务器存储写入失败', 500); }
}

function fb_client_ip() {
  return $_SERVER['HTTP_X_FORWARDED_FOR'] ?? ($_SERVER['REMOTE_ADDR'] ?? '');
}

function fb_now_ms() { return (int)(microtime(true) * 1000); }

function fb_date_str($ms) { return date('Y-m-d H:i', (int)($ms / 1000)); }

/** 简单令牌：HMAC(token_secret, user|YYYYMMDD)，当日有效 */
function fb_token_for($user) {
  $keys = fb_keys();
  return hash_hmac('sha256', $user . '|' . date('Ymd'), (string)($keys['token_secret'] ?? ''));
}

function fb_check_token($user, $token) {
  $keys = fb_keys();
  if (($user ?? '') !== ($keys['admin_user'] ?? '')) return false;
  if (!is_string($token) || !hash_equals(fb_token_for($user), $token)) return false;
  return true;
}
